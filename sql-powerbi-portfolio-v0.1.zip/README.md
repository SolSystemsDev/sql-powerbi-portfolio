# SQL & Power BI Portfolio

**Project 002 · Module 01 · Financial Budget vs. Actual Analytics · v0.1**

**Developer:** Jonathon McDonnell · **GitHub:** [SolSystemsDev](https://github.com/SolSystemsDev) · **Location:** San Antonio, Texas

A **reproducible, synthetic financial analytics project** demonstrating SQL-based transformations, expense classification, fiscal-calendar data modeling, audit-ready reconciliation, executive KPI reporting, Python ETL, and a practical Power BI reconstruction guide.

> **Data safety:** Every department, GL account, transaction and financial figure is fictional and deterministically generated. This is not VIA, Higginbotham, Nexxis, or another employer's data, source code or proprietary system.

## Current status

- **Working, tested:** zero-dependency Python data generator, SQLite relational model and monthly variance view, ETL/reconciliation pipeline, FY2026 reports, executive HTML dashboard, SVG chart, and automated unit tests.
- **Implementation references (not engine-validated):** SQL Server/T-SQL scripts, Power Query M and DAX definitions.
- **Not present:** a Power BI `.pbix`. This portfolio does not claim a tested Desktop report.

## Visual output

**[Open the generated executive dashboard](reports/executive_dashboard.html)** · **[View the monthly expense chart](reports/charts/monthly_spend.svg)**

The dashboard displays FY2026 expense plan vs actual across six fictional departments and eight GL accounts, including labor/non-labor classification, departmental expense trends, monthly variances and the largest GL drivers.

### FY2026 benchmark (synthetic only)

| KPI | Value |
|---|---:|
| Budget | $31,109,140.29 |
| Actual | $31,352,851.47 |
| Expense variance (actual − budget) | **+$243,711.18 unfavorable** |
| FY | Oct 1, 2025 – Sep 30, 2026 |
| Budget ledger entries (FY2025 + FY2026) | 1,152 |
| Synthetic expense transactions (FY2025 + FY2026) | 3,465 |

## Run it in GitHub Codespaces (iPhone-friendly)

GitHub Codespaces provides a Linux terminal in the browser. Python 3.11+ and Git are the only required tools. No SQL Server, Power BI Desktop, Docker or pip installs are needed for v0.1.

From the repository root:

```bash
python3 scripts/build.py
python3 -m unittest discover -s tests -v
```

A successful build prints `BUILD SUCCESS` and the benchmark values. The tests should finish with `Ran 11 tests` and `OK`. The script recreates `data/processed/finance_analytics.db` locally (excluded from Git) and regenerates the committed CSV, SVG, HTML and JSON outputs.

### What the ETL actually does

1. Generates synthetic departments, GL classifications, transaction-level actuals, monthly budgets and a daily fiscal calendar using a fixed seed.
2. Creates a SQLite database with foreign keys, checks, indexes and a unique budget grain.
3. Aggregates transactions into fiscal-month/department/GL spend before joining to budget, preventing duplicate-budget multiplication.
4. Enforces reconciliation: raw-ledger totals equal the combined monthly reporting view.
5. Exports monthly detail, department and GL rollups, unfavorable budget exceptions and an executive KPI JSON file.
6. Generates an accessible responsive HTML management report and vector visualization.

## Fiscal and financial definitions

FY is **October–September** and named by its end year (FY2026 = October 2025 through September 2026). Fiscal month 1 is October; fiscal month 12 is September. Source monetary fields are **integer cents**, preventing floating-point reconciliation drift. Positive expense variance (`Actual - Budget`) represents **unfavorable overspend**. FYTD % is derived from aggregated dollars rather than averaged monthly percentages.

**Partial FYTD support:** In `src/finance_portfolio/pipeline.py`, `report_data(conn, 2026, 6)` filters FY2026 through March (fiscal months 1–6). The shipped executive dashboard defaults to full FY2026.

## Repository map

```text
sql-powerbi-portfolio/
├── README.md                            # This page
├── requirements.txt                     # No external packages
├── data/
│   ├── synthetic/                       # Fictional input CSVs
│   └── processed/                       # Report CSVs, executive KPI JSON, runtime SQLite DB (ignored)
├── src/finance_portfolio/
│   ├── generator.py                      # Deterministic data factory
│   ├── pipeline.py                       # Load, validate, SQL views and exports
│   └── rendering.py                      # Responsive HTML and SVG output
├── scripts/build.py                      # Run everything
├── sql/
│   ├── sqlite/schema.sql                 # Executed in tests / pipeline
│   └── tsql/                             # SQL Server reference implementations
├── powerbi/
│   ├── dax/finance_measures.dax          # Measures to create manually
│   ├── power_query/                      # M transformation references
│   └── README.md                         # Import / model / relationships guide
├── docs/
│   ├── data_model.md                     # Star schema / lineage / conventions
│   └── validation.md                     # Test coverage / results / limits
├── reports/
│   ├── executive_dashboard.html          # Functional static executive report
│   └── charts/monthly_spend.svg          # Accessible vector budget-actual bars
├── tests/test_portfolio.py               # Standard-library unittest suite
└── .github/workflows/validate.yml        # CI rebuild + tests + deterministic diff
```

## Data model and BI measures

[Schema, lineage and fiscal definitions](docs/data_model.md) · [Power BI reconstruction instructions](powerbi/README.md) · [DAX measures](powerbi/dax/finance_measures.dax) · [Validation expectations](docs/validation.md)

- Labor vs Non-Labor classifications are stored on the GL dimension.
- Both budget and actual facts share date, department and GL dimensions.
- SQL aggregates actuals at the budget grain; views expose detail and report-ready rollups.
- DAX references include fiscal YTD, MTD, variance $/%, labor share, and cost components.
- The SQL Server/T-SQL equivalent is clearly separated from the **executed** SQLite implementation; T-SQL has not been run against SQL Server.

## Testing and governance

Automated tests cover October/September rollover, fiscal quarters, source determinism, partial/full YTD, dimension reconciliation, foreign-key constraints, required classification and positive variance sign convention. The build fails on foreign-key or ledger/view reconciliation errors. GitHub Actions runs the build and 11 tests on pushes and pull requests, and verifies generated source/report artifacts haven't drifted.

### Scope roadmap

- **Module 1 (v0.1 — working):** expense Budget vs Actual, financial variance reporting, fiscal YTD, GL/department rollups, labor mix, exception review, data quality controls and mobile-preview dashboard.
- **Module 1 (future):** build and verify an actual Power BI Desktop `.pbix`, fiscal period slicers, drill-through and formal semantic model screenshots.
- **Module 2:** synthetic sales, commission accruals, A/R aging, forecast tracking and CRM-to-ERP reconciliation.
- **Module 3:** synthetic supply chain inventory, delivery windows, logistics KPIs and cost-to-serve analysis.
- **Module 4:** ETL architecture, row-level quality audit, run logs, governance controls and query optimization.

## License and use

Educational/public portfolio demonstration. The source uses only fictional data. No connection to, endorsement by, or actual reporting from the developer's previous employers is implied.
